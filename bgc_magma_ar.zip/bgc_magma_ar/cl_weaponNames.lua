AddTextEntry("WEAPON_BGC_MAGMA_AR", "bgc_magma_ar")
